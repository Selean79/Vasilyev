Heapar Software
http://www.heapar.com

Heapar Essential Library .NET 
Heapar Essential Library allows you  to  create pretty and powerful user 
interfaces. The library consists of ActivePanel, Bevel, CategoryButtons,
Resizer,  HeaparGrid  etc. We add new features every month. Register now 
and get free updates in 1 year.

http://www.heapar.com/products.php?lang=1&id=1



Copyright
The licence include all source code files. All source codes are property
of  Heapar  Software.  You  can  use  it  for  investigation only or for 
changing  to  personal  efforts.  The  source  code  files  are for your
personal use  only.  You can not distribute changed or  not  changed the
source files in any way. 

You can distribute the Heapar libraries with your products only. You can
not distribute  the  libraries  or  the source code files to third party
users.  One  user  may install and use copies of the software to design,
develop, test and demonstrate your programs.

We  use  the  watermarks  to  protect our property. There will be several 
watermarks in your source codes files. If we find our source codes in the
Internet  we  could  find  source  of  distribution  using the watermark. 
Watermark contains the person name who bought the licence.

You may not

- alter  any  copyright , trademark or patent notice in the Distributable 
  Code; 
- use  Heapar  Software's  trademarks in your programs' names or in a way
  that  suggests  your  programs  come  from  or  are  endorsed by Heapar 
  Software; 
- include libraries in malicious, deceptive or unlawful programs; 
- modify  or  distribute  the  source code so that any part of it becomes
  subject  to  an  Excluded  License.  An  Excluded  License  is one that
  requires, as a condition of use, modification or distribution, that the
  code be  disclosed  or  distributed in source code form; or others have 
  the right to modify it. 
